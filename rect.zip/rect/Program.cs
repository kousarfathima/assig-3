﻿using System;

interface IShape
{
    double GetArea();
    double GetPerimeter();
}

class Rectangle : IShape
{
    private double length;
    private double width;

    public Rectangle(double length, double width)
    {
        this.length = length;
        this.width = width;
    }

    public double GetArea()
    {
        return length * width;
    }

    public double GetPerimeter()
    {
        return 2 * (length + width);
    }
}

class Square : IShape
{
    private double side;

    public Square(double side)
    {
        this.side = side;
    }

    public double GetArea()
    {
        return side * side;
    }

    public double GetPerimeter()
    {
        return 4 * side;
    }
}

class shape
{
    static void Main(string[] args)
    {
        Rectangle rect = new Rectangle(7, 4);
        Console.WriteLine("Rectangle:");
        Console.WriteLine("Area: {0} Perimeter: {1}", rect.GetArea(), rect.GetPerimeter());

        Square sq = new Square(4);
        Console.WriteLine("Square:");
        Console.WriteLine("Area: {0} Perimeter: {1}", sq.GetArea(), sq.GetPerimeter());
    }
}
