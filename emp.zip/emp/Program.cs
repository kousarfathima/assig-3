﻿using System;
public abstract class Employee
{
    public  string? name { get; set; }
    public abstract double salary { get; set;}
}

public class Driver : Employee
{
    public override double salary { get; set;}
   
}

public class Developer : Employee
{
    public override double salary { get; set;}
    
}
class Program
{
    static void Main(string[] args)
    {
        Driver driver = new Driver();
        driver.name = "sara";
        driver.salary = 3000;
         Console.WriteLine("Salary of {0}: {1}",driver.name, driver.salary);
        
        Developer developer = new Developer();
        developer.name = "zara";
        developer.salary = 5000;
       Console.WriteLine("Salary of {0}: {1}", developer.name, developer.salary);

        Console.ReadLine();
    }
}
